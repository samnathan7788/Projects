import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
public class GradebookTest {
      private GradeBook g1;
  	@Before
      public void setUp() {
        	g1 = new GradeBook(5);
        	g1.addScore(50);
        	g1.addScore(75);
        	g1.addScore(100);
        	g1.addScore(90);
  	}
  	
      public void tearDown() {
        	g1 = null;
  	}
  	
      public void scoreAdd() {
        	g1 = new GradeBook(2);
        	//Intialize gradebook with 2
            assertEquals(0, g1.getScoreSize());
            assertEquals(0, g1.sum(), 0.0001);
        	// Start score is 0
        	g1.addScore(99);
        	// Add 1 to score
            assertEquals(1, g1.getScoreSize());
            assertEquals(99, g1.sum(), 0.0001);
        	// aSize 1 and the sum is 99 
        	g1.addScore(25);
        	// Plus one score
            assertEquals(2, g1.getScoreSize());
            assertEquals(99 + 25, g1.sum(), 0.0001);
            
        	g1.addScore(77);
            assertEquals(2, g1.getScoreSize());
            
            assertEquals(99 + 25, g1.sum(), 0.0001);
            assertFalse(g1.addScore(87));
            
            assertEquals(2, g1.getScoreSize());
            
            assertEquals(99 + 25, g1.sum(), 0.0001);
  	}
  	@Test
      public void Sum() {
            assertEquals(90 + 100 + 75 + 50, g1.sum(), 0.0001);
        	g1.addScore(55);
        	
            assertEquals(100 + 90 + 50 + 55 + 75, g1.sum(), 0.0001);
  	}
  	@Test
      public void Min() {
        	
            assertEquals(50, g1.minimum(), 0.0001);          
        	g1.addScore(22);        	
            assertEquals(22, g1.minimum(), 0.0001);
  	}
  	@Test
      public void tesFnl() {        
            assertEquals(75 + 100 + 90, g1.finalScore(), 0.0001);        	
        	g1.addScore(22);        	
        	
            assertEquals(50 + 75 + 100 + 90, g1.finalScore(), 0.0001);        	
        	g1 = new GradeBook(2);        	
        	
            assertEquals(0, g1.finalScore(), 0.0001);
  	}
  	@Test
      public void tesGt() {        	
            assertEquals(4, g1.getScoreSize());
            
        	g1.addScore(22);
            assertEquals(5, g1.getScoreSize());      
            
        	g1.addScore(76);
            assertEquals(5, g1.getScoreSize());
  	}
  	@Test
      public void tesoStr() {
            assertTrue(g1.toString().equals("50.0 75.0 100.0 90.0"));
        	g1.addScore(22);
            assertTrue(g1.toString().equals("50.0 75.0 100.0 90.0 22.0"));
        	g1.addScore(80);
            assertTrue(g1.toString().equals("50.0 75.0 100.0 90.0 22.0"));
  	}
}
 
